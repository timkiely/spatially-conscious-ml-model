# This function creates the ZIPCODE modeling data

create_zipcode_data <- function(pluto_with_sales_infile = "data/processing steps/p05_pluto_with_sales.rds"
                                , outfile = "data/processing steps/p07_zipcode_model_data.rds") {
  
  message("TODO: function to create the ZIPCODE modeling data")
}