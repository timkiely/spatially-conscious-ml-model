# This function creates the RADII modeling data

create_radii_data <- function(pluto_with_sales_infile = "data/processing steps/p05_pluto_with_sales.rds"
                              , outfile = "data/processing steps/p08_radii_model_data.rds") {
  
  message("TODO: function to create the RADII modeling data")
}