
# This function combines PLUTO with the sales&pad data

combine_pluto_with_sales <- function(pluto_infile = "data/processing steps/p01_pluto_raw.rds"
                                     , sales_pad_infile = "data/processing steps/p04_sales_and_pad.rds"
                                     , outfile = "data/processing steps/p05_pluto_with_sales.rds") {
  
  message("Combinging PLUTO with Sales data")
  message("Loading data...")  
  pluto_raw <- read_rds(pluto_infile) %>% mutate(bbl = paste(BoroCode,as.numeric(Block),as.numeric(Lot),sep="_"))
  sales_pad_raw <- read_rds(sales_pad_infile)
  
  # normalize sales that take place more than 1 per year:
  message("Normalizing the sales data...")  
  
  merge_time <- Sys.time()
  sales <- 
    sales_pad_raw %>% 
    group_by(pluto_bbl, `SALE YEAR`) %>% 
    summarise(`BUILDING CLASS CATEGORY` = head(`BUILDING CLASS CATEGORY`, 1)
              ,`TAX CLASS AT PRESENT` = head(`TAX CLASS AT PRESENT`, 1)
              , `BUILDING CLASS AT PRESENT` = head(`BUILDING CLASS AT PRESENT`, 1)
              , `ZIP CODE` = head(`ZIP CODE`, 1)
              , `RESIDENTIAL UNITS` = mean(`RESIDENTIAL UNITS`, na.rm = TRUE)
              , `COMMERCIAL UNITS` = mean(`COMMERCIAL UNITS`, na.rm = TRUE)
              , `TOTAL UNITS` = mean(`TOTAL UNITS`, na.rm = TRUE)
              , `LAND SQUARE FEET` = mean(`LAND SQUARE FEET`, na.rm = TRUE)
              , `GROSS SQUARE FEET` = mean(`GROSS SQUARE FEET`, na.rm = TRUE)
              , `YEAR BUILT` = head(`YEAR BUILT`, 1)
              , `TAX CLASS AT TIME OF SALE` = head(`TAX CLASS AT TIME OF SALE`, 1)
              , `BUILDING CLASS AT TIME OF SALE` = head(`BUILDING CLASS AT TIME OF SALE`, 1)
              , `SALE PRICE` = mean(`SALE PRICE`, na.rm = T)
              , `TOTAL SALES` = sum(`SALE PRICE`, na.rm = T)
              , Year = head(Year, 1)
              , SALE_DATE = mean(SALE_DATE, na.rm = T)
              , SALE_YEAR = head(SALE_YEAR, 1)
              , bbl = head(bbl, 1)
              , Annual_Sales = n()
              ) %>% 
    mutate(Sold = 1)
  
  message("Merging sales data with PLUTO...")  
  pluto_with_sales <- 
    left_join(pluto_raw, sales, by = c("bbl"="pluto_bbl", "Year"="SALE YEAR")) %>% 
    select(-contains(".y")) %>% mutate(Sold = if_else(is.na(Sold),0,Sold))
  
  merge_end <- Sys.time()
  message("     ...done")  
  message("Merge time: ", round(merge_end-merge_time, 2), units(merge_end-merge_time))
  
  message("Writing plto with sales to disk...")  
  write_rds(pluto_with_sales, outfile)
  message("Done. Pluto combined with sales and written to ", outfile)  
}
